//
//  XYViewController.m
//  Paste2ComunicateTest
//
//  Created by LL on 4/22/14.
//  Copyright (c) 2014 LL. All rights reserved.
//

//marco

#define TEST_PASTEBOARDWITHNAME
#define TEST_PASTEBOARD_GENERAL
#define TEST_PASTEBOARD_UNIQUE

#import "XYViewController.h"

@interface XYViewController ()

@end

@implementation XYViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    switch (DEBUG) {
        case 1:
            [identifier setText:@"com.tom.cat"];
            [label setText:@"tom1"];
            break;
        case 2:
            [identifier setText:@"com.tom.pig"];
            [label setText:@"tom2"];
            break;
        case 3:
            [identifier setText:@"com.autonavi.amap"];
            [label setText:@"jerry"];
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (IBAction)buttonClicked:(id)sender
{
    switch (DEBUG) {
        case 1:
            [self p_tom1SetString];
            break;
        case 2:
            [self p_tom2GetString];
            break;
        case 3:
            [self p_jerryGetString];
            break;
        default:
            break;
    }
}

- (void)p_tom1SetString
{
#ifdef TEST_PASTEBOARDWITHNAME
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithName:@"LL" create:YES];
#elif  TEST_PASTEBOARD_GENERAL
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
#elif  TEST_PASTEBOARD_UNIQUE
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithUniqueName];
#endif
    
    [pasteboard setString:textField.text];
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"message" message:@"ok copy" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:@"确定",nil];
    [alertView show];
    
}

- (void)p_tom2GetString
{
#ifdef TEST_PASTEBOARDWITHNAME
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithName:@"LL" create:YES];
#elif  TEST_PASTEBOARD_GENERAL
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
#elif  TEST_PASTEBOARD_UNIQUE
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithUniqueName];
#endif
    textField.text = pasteboard.string;
    NSLog(@"tom2:%@",pasteboard.string);
}

- (void)p_jerryGetString
{
#ifdef TEST_PASTEBOARDWITHNAME
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithName:@"LL" create:YES];
#elif  TEST_PASTEBOARD_GENERAL
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
#elif  TEST_PASTEBOARD_UNIQUE
    UIPasteboard *pasteboard = [UIPasteboard pasteboardWithUniqueName];
#endif
    textField.text = pasteboard.string;
    NSLog(@"jerry:%@",pasteboard.string);
}
@end
