//
//  main.m
//  Paste2ComunicateTest
//
//  Created by LL on 4/22/14.
//  Copyright (c) 2014 LL. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XYAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XYAppDelegate class]));
    }
}
