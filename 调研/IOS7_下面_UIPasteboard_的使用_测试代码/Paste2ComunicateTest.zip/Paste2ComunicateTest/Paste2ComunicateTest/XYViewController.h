//
//  XYViewController.h
//  Paste2ComunicateTest
//
//  Created by LL on 4/22/14.
//  Copyright (c) 2014 LL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYViewController : UIViewController
{
    IBOutlet UILabel *label;
    IBOutlet UILabel *identifier;
    
    IBOutlet UITextField *textField;
}

- (IBAction)buttonClicked:(id)sender;
@end
