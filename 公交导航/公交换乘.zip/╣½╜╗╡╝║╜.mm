<map version="1.0.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1400123229369" ID="ID_913995108" MODIFIED="1400123257232" TEXT="&#x516c;&#x4ea4;&#x5bfc;&#x822a;">
<node CREATED="1400123264152" ID="ID_1257173474" MODIFIED="1400143756655" POSITION="right" TEXT="&#x7ebf;&#x8def;&#x63d0;&#x9192;">
<node CREATED="1400123277610" ID="ID_1914200276" MODIFIED="1400123427303" TEXT="&#x8d77;&#x6b65;&#x63d0;&#x9192;">
<node CREATED="1400123343915" ID="ID_1413393335" MODIFIED="1400123606183" TEXT="&#x6837;&#x5f0f;&#xff1a;&#x6b65;&#x884c;*&#x7c73;&#x5230;*&#xff08;&#x4e0a;&#x8f66;&#x7ad9;&#x540d;&#x79f0;&#xff09; &#x5750;*&#xff08;&#x7ebf;&#x8def;&#x540d;&#x79f0;&#xff09;"/>
<node CREATED="1400123613216" ID="ID_1650030116" MODIFIED="1400142164963" TEXT="showTip&#xff08;Type_start,  stTipInfo&#xff09;">
<node CREATED="1400123861268" ID="ID_951675041" MODIFIED="1400123869794" TEXT="distance"/>
<node CREATED="1400125920617" ID="ID_56139497" MODIFIED="1400125922622" TEXT="time"/>
<node CREATED="1400126794809" ID="ID_1521141297" MODIFIED="1400126801972" TEXT="StationNum"/>
<node CREATED="1400123870427" ID="ID_411339043" MODIFIED="1400125798719" TEXT="StartStationName"/>
<node CREATED="1400125841767" ID="ID_383108694" MODIFIED="1400125898846" TEXT="StartExitName"/>
<node CREATED="1400125805982" ID="ID_1711325449" MODIFIED="1400125817764" TEXT="EndStationName"/>
<node CREATED="1400125901561" ID="ID_913186157" MODIFIED="1400125909455" TEXT="EndExitName"/>
<node CREATED="1400123879231" ID="ID_114206346" MODIFIED="1400123883151" TEXT="lineName"/>
<node CREATED="1400126948846" ID="ID_984035673" MODIFIED="1400142209910" TEXT="GroupId"/>
</node>
<node CREATED="1400123831196" ID="ID_1516676594" MODIFIED="1400126004768" TEXT="hideTip&#xff0c;playNaviSound"/>
<node CREATED="1400124015109" ID="ID_1819135146" MODIFIED="1400124477524" TEXT="&#x542f;&#x52a8;&#x6761;&#x4ef6;&#xff1a;&#x5f00;&#x59cb;&#x5bfc;&#x822a;&#x65f6;&#xff0c; &#x5047;&#x5b9a;&#x4f4d;&#x4e8e;&#x6b65;&#x884c;&#x8d77;&#x70b9;"/>
<node CREATED="1400124073004" ID="ID_94498099" MODIFIED="1400143550689" TEXT="&#x9000;&#x51fa;&#x6761;&#x4ef6;&#xff1a;&#x89e6;&#x53d1;&#x5176;&#x4ed6;Tip&#x63d0;&#x9192;"/>
<node CREATED="1400124211752" ID="ID_750540881" MODIFIED="1400132484974" TEXT="GroupId&#xff0c;type"/>
</node>
<node CREATED="1400123314770" ID="ID_1450549628" MODIFIED="1400123531303" TEXT="&#x6362;&#x4e58;&#x63d0;&#x9192;">
<node CREATED="1400137639658" ID="ID_1192649170" MODIFIED="1400149314905" TEXT="&#xff1f;&#x4e0b;&#x8f66;&#x539f;&#x5730;&#x6362;&#x4e58;">
<node CREATED="1400137737231" ID="ID_1294392283" MODIFIED="1400137740463" TEXT="&#x4e0b;&#x8f66;&#x540e;&#x6362;*&#x7ebf;&#x8def;&#x540d;&#x79f0;*&#xff08;&#x7ecf;&#x8fc7;X&#x7ad9;&#xff0c;&#x7ea6;X&#x5206;&#x949f;&#xff09;&#xff0c;*&#x4e0b;&#x8f66;&#x7ad9;*&#x4e0b;&#x8f66;"/>
<node CREATED="1400149753578" ID="ID_1070849898" MODIFIED="1400149772857" TEXT="showTip&#xff08;Type_BusTransfer, stTipInfo&#xff09; "/>
<node CREATED="1400139058944" ID="ID_873353142" MODIFIED="1400143060158" TEXT="&#x89e6;&#x53d1;&#x6761;&#x4ef6;&#xff1a;&#x8ddd;&#x79bb;&#x4e0b;&#x8f66;&#x7ad9;&#x4e0d;&#x8db3;50&#x7c73;&#xff0c;&#x4e0b;&#x8f66;&#x7ad9;&#x548c;&#x6362;&#x4e58;&#x4e0a;&#x8f66;&#x7ad9;&#x540c;&#x540d;&#xff0c;&#x4e14;&#x8ddd;&#x79bb;&#x5f88;&#x8fd1;"/>
</node>
<node CREATED="1400137636516" ID="ID_1214650008" MODIFIED="1400150057981" TEXT="&#x4e0b;&#x8f66;&#x6b65;&#x884c;&#x540e;&#x6362;&#x4e58;">
<node CREATED="1400123536968" ID="ID_1986804163" MODIFIED="1400123909531" TEXT="&#x6837;&#x5f0f;&#xff1a;&#x6b65;&#x884c;*&#x7c73;&#x5230;*&#xff08;&#x4e0a;&#x8f66;&#x7ad9;&#x540d;&#x79f0;&#xff09; &#x6362;*&#xff08;&#x7ebf;&#x8def;&#x540d;&#x79f0;&#xff09;"/>
<node CREATED="1400123924227" ID="ID_850113870" MODIFIED="1400149867005" TEXT="showTip&#xff08;Type_Transfer, stTipInfo&#xff09;"/>
<node CREATED="1400149225439" ID="ID_305692358" MODIFIED="1400149602421" TEXT="&#x89e6;&#x53d1;&#x6761;&#x4ef6;&#xff1a;&#x5230;&#x8fbe;&#x4e0b;&#x8f66;&#x7ad9;&#xff0c;&#x4e0b;&#x8f66;&#x540e;&#x9700;&#x8d70;&#x4e00;&#x5b9a;&#x8ddd;&#x79bb;&#x624d;&#x80fd;&#x6362;&#x4e58;"/>
</node>
</node>
<node CREATED="1400123290601" ID="ID_217068276" MODIFIED="1400123311697" TEXT="&#x516c;&#x4ea4;/&#x5730;&#x94c1;&#x4e0a;&#x4e0b;&#x8f66;&#x63d0;&#x9192;">
<node CREATED="1400125061971" ID="ID_1195800158" MODIFIED="1400125084602" TEXT="&#x4e0a;&#x8f66;&#x63d0;&#x9192;">
<node CREATED="1400125105040" ID="ID_423532339" MODIFIED="1400125141945" TEXT="&#x5230;&#x8fbe;*&#x4e0a;&#x8f66;&#x7ad9;&#x70b9;&#x540d;&#x79f0;*&#x5750;*&#x7ebf;&#x8def;&#x540d;&#x79f0;*&#xff08;&#x7ecf;&#x8fc7;*&#x7ad9;&#x6570;*&#xff0c;&#x7ea6;X&#x5206;&#x949f;&#xff09;&#x5728;*&#x4e0b;&#x8f66;&#x7ad9;&#x540d;&#x79f0;*&#x4e0b;"/>
<node CREATED="1400125146249" ID="ID_447868070" MODIFIED="1400125265527" TEXT="&#x5230;&#x8fbe;*&#x4e0a;&#x7ad9;&#x70b9;&#x540d;&#x79f0;*&#x4ece;X&#x53e3;&#x8fdb;&#xff0c;&#x5750;*&#x7ebf;&#x8def;&#x540d;&#x79f0;*&#xff08;&#x7ecf;&#x8fc7;*&#x7ad9;&#x6570;*&#xff0c;&#x7ea6;X&#x5206;&#x949f;&#xff09;&#x5728;*&#x4e0b;&#x8f66;&#x7ad9;&#x540d;&#x79f0;*&#x4e0b;"/>
<node CREATED="1400123613216" FOLDED="true" ID="ID_1922453449" MODIFIED="1400131563793" TEXT="showTip&#xff08;Type_getOn,  stTipInfo&#xff09;">
<node CREATED="1400123861268" ID="ID_1583218261" MODIFIED="1400123869794" TEXT="distance"/>
<node CREATED="1400125920617" ID="ID_1477700918" MODIFIED="1400125922622" TEXT="time"/>
<node CREATED="1400126794809" ID="ID_275876271" MODIFIED="1400126801972" TEXT="StationNum"/>
<node CREATED="1400123870427" ID="ID_1833105587" MODIFIED="1400125798719" TEXT="StartStationName"/>
<node CREATED="1400125841767" ID="ID_845678398" MODIFIED="1400125898846" TEXT="StartExitName"/>
<node CREATED="1400125805982" ID="ID_1255345425" MODIFIED="1400125817764" TEXT="EndStationName"/>
<node CREATED="1400125901561" ID="ID_1253593421" MODIFIED="1400125909455" TEXT="EndExitName"/>
<node CREATED="1400123879231" ID="ID_269259998" MODIFIED="1400123883151" TEXT="lineName"/>
<node CREATED="1400126948846" ID="ID_847049774" MODIFIED="1400126990420" TEXT="BusGroupId"/>
</node>
<node CREATED="1400150780280" ID="ID_1908961600" MODIFIED="1400150821766" TEXT="&#x89e6;&#x53d1;&#x6761;&#x4ef6;&#xff1a;&#x79bb;&#x4e0a;&#x8f66;&#x70b9;&#x4e0d;&#x8db3;50m"/>
<node CREATED="1400130613917" ID="ID_1947189183" MODIFIED="1400150831543" TEXT="&#x9000;&#x51fa;&#x6761;&#x4ef6;&#xff1a;&#x5230;&#x4e0a;&#x8f66;&#x70b9;&#x4f4d;&#x7f6e;&#x6301;&#x7eed;&#x53d8;&#x8fdc;&#xff0c;&#x8131;&#x79bb;&#x4e0a;&#x8f66;&#x70b9;"/>
<node CREATED="1400126906501" ID="ID_446221006" MODIFIED="1400127115042" TEXT="&#x591a;&#x7ebf;&#x8def;&#x63d0;&#x793a;&#x7531;&#x5ba2;&#x6237;&#x7aef;&#x5b8c;&#x6210;"/>
</node>
<node CREATED="1400129986791" ID="ID_544099094" MODIFIED="1400149644706" TEXT="&#x5230;&#x7ad9;&#x63d0;&#x9192;">
<node CREATED="1400130142742" ID="ID_1298680060" MODIFIED="1400130156822" TEXT="&#x5373;&#x5c06;&#x5230;&#x8fbe;*&#x4e0b;&#x8f66;&#x7ad9;&#x540d;&#x79f0;*&#xff0c;&#x8bf7;&#x60a8;&#x51c6;&#x5907;&#x4e0b;&#x8f66;"/>
<node CREATED="1400130157416" ID="ID_1926263036" MODIFIED="1400130176121" TEXT="&#x5373;&#x5c06;&#x5230;&#x8fbe;*&#x4e0b;&#x8f66;&#x7ad9;&#x540d;&#x79f0;*&#xff0c;&#x8bf7;&#x7559;&#x610f;&#x62a5;&#x7ad9;&#xff0c;&#x51c6;&#x5907;&#x4e0b;&#x8f66;&#xff0c;X&#x53e3;&#x51fa;"/>
<node CREATED="1400123613216" FOLDED="true" ID="ID_1839987118" MODIFIED="1400131577168" TEXT="showTip&#xff08;Type_getOff,  stTipInfo&#xff09;">
<node CREATED="1400123861268" ID="ID_1884612622" MODIFIED="1400123869794" TEXT="distance"/>
<node CREATED="1400125920617" ID="ID_1844544163" MODIFIED="1400125922622" TEXT="time"/>
<node CREATED="1400126794809" ID="ID_1916627141" MODIFIED="1400126801972" TEXT="StationNum"/>
<node CREATED="1400123870427" ID="ID_1427906407" MODIFIED="1400125798719" TEXT="StartStationName"/>
<node CREATED="1400125841767" ID="ID_1255358277" MODIFIED="1400125898846" TEXT="StartExitName"/>
<node CREATED="1400125805982" ID="ID_891841447" MODIFIED="1400125817764" TEXT="EndStationName"/>
<node CREATED="1400125901561" ID="ID_1588861350" MODIFIED="1400125909455" TEXT="EndExitName"/>
<node CREATED="1400123879231" ID="ID_239129988" MODIFIED="1400123883151" TEXT="lineName"/>
<node CREATED="1400126948846" ID="ID_1797704905" MODIFIED="1400126990420" TEXT="BusGroupId"/>
</node>
<node CREATED="1400130178675" ID="ID_577766448" MODIFIED="1400150767159" TEXT="&#x89e6;&#x53d1;&#x6761;&#x4ef6;&#xff1a;&#x5730;&#x94c1;2km, &#x516c;&#x4ea4;1km&#x5185;"/>
<node CREATED="1400130704103" ID="ID_734045514" MODIFIED="1400131721007" TEXT="&#x9000;&#x51fa;&#x6761;&#x4ef6;&#xff1a;&#x88ab;&#x5176;&#x4ed6;&#x63d0;&#x793a;&#x53d6;&#x4ee3;&#xff0c;&#x6216;&#x8131;&#x79bb;&#x4e0b;&#x8f66;&#x70b9;&#x8303;&#x56f4;"/>
</node>
</node>
<node CREATED="1400124424917" ID="ID_248713506" MODIFIED="1400124618576" TEXT="&#x5230;&#x8fbe;&#x63d0;&#x9192;">
<node CREATED="1400124445482" ID="ID_160867598" MODIFIED="1400141764855" TEXT="&#x5230;&#x8fbe;&#x7ec8;&#x70b9;">
<node CREATED="1400124460749" ID="ID_1043023744" MODIFIED="1400141895999" TEXT="&#x6761;&#x4ef6;&#xff1a;&#x8ddd;&#x79bb;&#x7ec8;&#x70b9;50m(?)"/>
<node CREATED="1400124845482" ID="ID_144581784" MODIFIED="1400140341717" TEXT="ArriveDestination()"/>
</node>
<node CREATED="1400141780412" ID="ID_1490606330" MODIFIED="1400142121801" TEXT="&#xff1f;&#x5230;&#x8fbe;&#x6362;&#x4e58;&#x7ad9;">
<node CREATED="1400141840806" ID="ID_402790955" MODIFIED="1400141876115" TEXT="&#x6761;&#x4ef6;&#xff1a;&#x8ddd;&#x79bb;&#x6362;&#x4e58;&#x7ad9;50m"/>
<node CREATED="1400150892899" ID="ID_1255637890" MODIFIED="1400151363058" TEXT="&#x4f5c;&#x7528;&#xff1a;&#x7ed9;&#x51fa;&#x5ba2;&#x6237;&#x7aef;&#x8981;&#x6c42;&#x7ebf;&#x8def;&#x9009;&#x62e9;&#x65f6;&#x673a;"/>
<node CREATED="1400139975388" ID="ID_557565854" MODIFIED="1400152319387" TEXT="ArriveTransferStop(newGroupId)"/>
</node>
</node>
</node>
<node CREATED="1400131826550" ID="ID_470838879" MODIFIED="1400141993503" POSITION="right" TEXT="&#x5173;&#x952e;&#x70b9;&#x63d0;&#x9192;&#xff08;&#x6b65;&#x884c;&#x8f6c;&#x5f2f;&#x3001;&#xff1f;&#x516c;&#x4ea4;&#x9014;&#x5f84;&#x7ad9;&#xff09;">
<node CREATED="1400125534544" ID="ID_1290244487" MODIFIED="1400125548517" TEXT="&#x8fdb;&#x5165;50&#x7c73;&#x5185;&#x7acb;&#x5373;&#x5207;&#x6362;"/>
<node CREATED="1400131885489" ID="ID_1864789830" MODIFIED="1400133076342" TEXT="showTurning(Type, TurnInfo)">
<node CREATED="1400132934632" ID="ID_1125587752" MODIFIED="1400136538132" TEXT="GroupId"/>
<node CREATED="1400136528495" ID="ID_1236583949" MODIFIED="1400142090256" TEXT="LinkId(&#x8fdb;&#x5165;&#x8def;&#x53e3;&#x7684;link&#x4e0b;&#x6807;&#xff0c;&#x3000;&#xff0d;&#xff11;&#x8868;&#x793a;&#x4f4d;&#x4e8e;&#x8d77;&#x70b9;)"/>
</node>
<node CREATED="1400131957128" ID="ID_675063831" MODIFIED="1400132000937" TEXT="hideTurning"/>
<node CREATED="1400125383962" ID="ID_886150568" MODIFIED="1400125670847" TEXT="&#x8fdf;&#x6ede;&#x8bbe;&#x8ba1;1&#xff0c; &#x9000;&#x51fa;&#x9700;&#x8981;&#x6301;&#x7eed;3&#x79d2;&#x5185;&#x4f4d;&#x7f6e;&#x5df2;&#x8fc7;&#x8f6c;&#x6298;&#x70b9;&#xff08;&#x6216;&#x7ad9;&#x70b9;&#xff09;"/>
<node CREATED="1400125446078" ID="ID_105998767" MODIFIED="1400125527489" TEXT="&#x8fdf;&#x6ede;&#x8bbe;&#x8ba1;2 &#xff0c;&#x518d;&#x8fdb;&#x5165;&#x9700;&#x8981;&#x6301;&#x7eed;3&#x79d2;&#x4f4d;&#x7f6e;&#x8fdb;&#x5165;&#x8f6c;&#x6298;&#x70b9;"/>
<node CREATED="1400125621567" ID="ID_1194367292" MODIFIED="1400126152623" TEXT="preStop&#xff0c;curStop"/>
</node>
<node CREATED="1400124720814" ID="ID_552743803" MODIFIED="1400127395700" POSITION="right" TEXT="&#x4f4d;&#x7f6e;&#x66f4;&#x65b0;">
<node CREATED="1400124739054" ID="ID_459597587" MODIFIED="1400144705496" TEXT="&#x6b65;&#x884c;&#x6bb5;&#xff1a;&#x66f4;&#x65b0;&#x5f53;&#x524d;&#x6bb5;&#x548c;&#x4e0b;&#x4e00;&#x6bb5;&#x8def;&#x540d;"/>
<node CREATED="1400124758008" ID="ID_954212290" MODIFIED="1400144728298" TEXT="&#x516c;&#x4ea4;&#x6bb5;&#xff1a;&#x66f4;&#x65b0;&#x5f53;&#x524d;&#x6bb5;&#x548c;&#x4e0b;&#x4e00;&#x6bb5;&#x7ad9;&#x540d;"/>
<node CREATED="1400125338545" ID="ID_691909880" MODIFIED="1400147730163" TEXT="updateNaviInfo&#xff08;BusNaviInfo&#xff09;">
<node CREATED="1400147745962" ID="ID_1270175096" MODIFIED="1400147764083" TEXT="&#x4f18;&#x5148;&#x63d0;&#x4f9b;">
<node CREATED="1400127652151" ID="ID_1934739086" MODIFIED="1400146758174" TEXT="m_CurGroupId&#xff08;&#xff0d;&#xff11;&#x8868;&#x793a;&#x672a;&#x5728;&#x8def;&#x4e0a;&#xff0c;&#x6b64;&#x65f6;&#x9664;&#x7ecf;&#x7eac;&#x5ea6;&#x5916;&#x5176;&#x4ed6;&#x503c;&#x65e0;&#x6548;&#xff09;"/>
<node CREATED="1400129854567" ID="ID_1749538322" MODIFIED="1400146780541" TEXT="m_GroupType(&#x6b65;&#x884c;&#x4e3a;&#xff10;&#xff0c;&#x516c;&#x4ea4;&#x4e3a;&#xff11;, ...)"/>
<node CREATED="1400132566683" ID="ID_1230168900" MODIFIED="1400146806190" TEXT="m_RemainStopNum;    //!&lt; GroupType&#x4e3a;&#x516c;&#x4ea4;&#x65f6;&#x6709;&#x6548;&#xff0c;&#x8868;&#x793a;&#x5269;&#x4f59;&#x7ad9;&#x6570;&#xff0c;&#x5426;&#x5219;&#x4e3a;-1&#x9;&#x9;"/>
<node CREATED="1400127533389" ID="ID_205128790" MODIFIED="1400146823971" TEXT="m_pCurStopName;   //!&lt; &#x5f53;&#x524d;&#x9053;&#x8def;&#x540d;&#x79f0;&#xff08;&#x6216;&#x4e0a;&#x4e00;&#x7ad9;&#x540d;&#xff09;&#xff0c;UTF8&#x7f16;&#x7801;&#x65b9;&#x5f0f;"/>
<node CREATED="1400127560019" ID="ID_1980689085" MODIFIED="1400147165418" TEXT="m_pNextStopName;  //!&lt; &#x4e0b;&#x6761;&#x9053;&#x8def;&#x540d;&#x79f0;&#xff08;&#x6216;&#x4e0b;&#x4e00;&#x7ad9;&#x540d;&#xff09;&#xff0c;UTF8&#x7f16;&#x7801;&#x65b9;&#x5f0f;"/>
<node CREATED="1400127721824" ID="ID_1908687358" MODIFIED="1400147310365" TEXT="m_pLastStopName;  //!&lt; &#x7ec8;&#x70b9;&#x7ad9;&#xff08;&#x4e0b;&#x8f66;&#x7ad9;&#xff09;&#x540d;&#xff0c;UTF8&#x7f16;&#x7801;&#x65b9;&#x5f0f;"/>
</node>
<node CREATED="1400147743528" ID="ID_1183429343" MODIFIED="1400147768771" TEXT="&#x540e;&#x671f;&#x63d0;&#x4f9b;">
<node CREATED="1400127599844" ID="ID_1474730710" MODIFIED="1400146868420" TEXT="m_CurLinkId;        //!&lt; &#x5f53;&#x524d;&#x6240;&#x5728;Link&#x7f16;&#x53f7;&#xff0c;&#x4ece;0&#x5f00;&#x59cb;&#xff0c;-1&#x65e0;&#x6548;"/>
<node CREATED="1400140468752" ID="ID_1421392507" MODIFIED="1400146879407" TEXT="m_CurPointId;       //!&lt; &#x5f53;&#x524d;&#x6240;&#x5728;Group&#x4e2d;&#x521a;&#x8def;&#x8fc7;&#x7684;&#x5f62;&#x72b6;&#x70b9;&#x53f7;&#xff0c;&#x4ece;0&#x5f00;&#x59cb;&#xff0c;-1&#x65e0;&#x6548;"/>
<node CREATED="1400130866093" ID="ID_662550666" MODIFIED="1400147511241" TEXT="m_RouteRemainDist;  //!&lt; &#x8def;&#x5f84;&#x5269;&#x4f59;&#x8ddd;&#x79bb;&#xff08;&#x5355;&#x4f4d;&#x7c73;&#xff09;"/>
<node CREATED="1400145177132" ID="ID_546512815" MODIFIED="1400147520165" TEXT="m_RouteRemainTime;  //!&lt; &#x8def;&#x5f84;&#x5269;&#x4f59;&#x65f6;&#x95f4;&#xff08;&#x5355;&#x4f4d;&#x79d2;&#xff09;"/>
<node CREATED="1400147525390" ID="ID_745578822" MODIFIED="1400147533387" TEXT="m_GroupRemainDist;  //!&lt; &#x5f53;&#x524d;Group&#x5269;&#x4f59;&#x8ddd;&#x79bb;&#xff08;&#x5355;&#x4f4d;&#x7c73;&#xff09;"/>
<node CREATED="1400147536149" ID="ID_385765126" MODIFIED="1400147544206" TEXT="m_GroupRemainTime;  //!&lt; &#x5f53;&#x524d;Group&#x5269;&#x4f59;&#x65f6;&#x95f4;&#xff08;&#x5355;&#x4f4d;&#x79d2;&#xff09;"/>
<node CREATED="1400140474280" ID="ID_1127351811" MODIFIED="1400146890687" TEXT="m_MatchState;       //!&lt; &#x5f53;&#x524d;&#x70b9;&#x4f4d;&#x662f;&#x5426;&#x5339;&#x914d;&#x5728;&#x8def;&#x4e0a;&#x9;0&#x8868;&#x793a;&#x672a;&#x5339;&#x914d;&#xff0c;1&#x8868;&#x793a;&#x5339;&#x914d;"/>
<node CREATED="1400127708384" ID="ID_565397059" MODIFIED="1400147856710" TEXT="m_Direction;        //!&lt; &#x65b9;&#x5411;&#xff08;&#x5355;&#x4f4d;&#x5ea6;&#xff09;&#xff0c;&#x4ee5;&#x6b63;&#x5317;&#x4e3a;&#x57fa;&#x51c6;&#xff0c;&#x987a;&#x65f6;&#x9488;&#x589e;&#x52a0;&#xff0c;&#x5339;&#x914d;&#x65f6;&#x4e3a;&#x8def;&#x5f84;&#x65b9;&#x5411;&#xff0c;&#x672a;&#x5339;&#x914d;&#x4e3a;&#x539f;&#x59cb;&#x503c;"/>
<node CREATED="1400140564442" ID="ID_718347212" MODIFIED="1400146916846" TEXT="m_Longitude;      //!&lt; &#x7ecf;&#x5ea6;&#xff0c;&#x5339;&#x914d;&#x72b6;&#x6001;&#x4e0b;&#x5728;&#x8def;&#x5f84;&#x4e0a;&#xff0c;&#x53cd;&#x4e4b;&#x4e3a;&#x539f;&#x59cb;GPS"/>
<node CREATED="1400130846447" ID="ID_278041405" MODIFIED="1400146935854" TEXT="m_Latitude;       //!&lt; &#x7eac;&#x5ea6;&#xff0c;&#x5339;&#x914d;&#x72b6;&#x6001;&#x4e0b;&#x5728;&#x8def;&#x5f84;&#x4e0a;&#xff0c;&#x53cd;&#x4e4b;&#x4e3a;&#x539f;&#x59cb;GPS"/>
</node>
</node>
</node>
</node>
</map>
