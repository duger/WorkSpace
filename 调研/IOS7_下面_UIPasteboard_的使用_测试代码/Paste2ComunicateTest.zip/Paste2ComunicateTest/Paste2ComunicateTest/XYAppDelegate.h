//
//  XYAppDelegate.h
//  Paste2ComunicateTest
//
//  Created by LL on 4/22/14.
//  Copyright (c) 2014 LL. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
